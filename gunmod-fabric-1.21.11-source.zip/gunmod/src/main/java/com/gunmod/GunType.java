package com.gunmod;

import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

import java.util.List;
import java.util.Locale;

public enum GunType {
    //      id             name            magazine name           dmg   cd  mag pel spread range  shot sound                                   pitch reload style                                       reloadTicks cycle
    PISTOL("pistol",       "Pistol",       "Pistol Magazine",      5.0f,  6, 12, 1, 0.010,  48, SoundEvents.ENTITY_ARROW_SHOOT,                  1.8f, "Quick mag swap",                                  30, false),
    REVOLVER("revolver",   "Revolver",     "Revolver Speedloader", 9.0f, 16,  6, 1, 0.004,  64, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST,        0.9f, "Speedloader: cylinder out, dump, load, close",    52, false),
    SMG("smg",             "SMG",          "SMG Magazine",         3.0f,  4, 30, 1, 0.045,  32, SoundEvents.ENTITY_ARROW_SHOOT,                  2.0f, "Fast drop-mag",                                   14, false),
    ASSAULT_RIFLE("assault_rifle", "Assault Rifle", "Rifle Magazine", 6.0f, 8, 30, 1, 0.015, 72, SoundEvents.ENTITY_BLAZE_SHOOT,                  1.6f, "Two-stage: mag out/in, then charging handle",     50, false),
    SHOTGUN("shotgun",     "Pump Shotgun", "Shotgun Shell Box",    4.0f, 24,  8, 8, 0.090,  20, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST,   0.7f, "Shell by shell, then pump",                       84, true),
    SNIPER_RIFLE("sniper_rifle", "Sniper Rifle", "Sniper Clip",   20.0f, 40,  5, 1, 0.000, 160, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST,   0.5f, "Clip load + bolt action",                         56, true);

    public final String id, displayName, magName, reloadName;
    public final float damage;
    public final int cooldown, magSize, pellets, range, reloadTicks;
    public final double spread;
    public final SoundEvent shotSound;
    public final float shotPitch;
    /** Whether firing needs a bolt/pump cycle (plays cycle sounds during the cooldown). */
    public final boolean cycles;

    GunType(String id, String displayName, String magName, float damage, int cooldown, int magSize, int pellets,
            double spread, int range, SoundEvent shotSound, float shotPitch, String reloadName, int reloadTicks,
            boolean cycles) {
        this.id = id; this.displayName = displayName; this.magName = magName; this.damage = damage;
        this.cooldown = cooldown; this.magSize = magSize; this.pellets = pellets; this.spread = spread;
        this.range = range; this.shotSound = shotSound; this.shotPitch = shotPitch; this.reloadName = reloadName;
        this.reloadTicks = reloadTicks; this.cycles = cycles;
    }

    public List<String> stats() {
        String dmg = String.format(Locale.ROOT, "%.1f", damage) + (pellets > 1 ? " x " + pellets + " pellets" : "")
                + " (" + String.format(Locale.ROOT, "%.1f", damage * pellets / 2f) + " hearts max)";
        return List.of(
                "Damage: " + dmg,
                "Magazine: " + magSize + " rounds",
                "Fire delay: " + String.format(Locale.ROOT, "%.2f", cooldown / 20.0) + "s",
                "Range: " + range + " blocks",
                "Reload: " + reloadName + " (" + String.format(Locale.ROOT, "%.1f", reloadTicks / 20.0) + "s)");
    }
}
