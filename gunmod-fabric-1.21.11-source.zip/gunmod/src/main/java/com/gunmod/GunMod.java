package com.gunmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class GunMod implements ModInitializer {
    public static final String MOD_ID = "gunmod";
    public static final RegistryKey<DamageType> BULLET =
            RegistryKey.of(RegistryKeys.DAMAGE_TYPE, Identifier.of(MOD_ID, "bullet"));

    @Override
    public void onInitialize() {
        ModComponents.init();
        ModItems.init();
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            for (ServerPlayerEntity player : world.getPlayers()) {
                GunItem.tickPlayer(world, player);
            }
        });
    }
}
