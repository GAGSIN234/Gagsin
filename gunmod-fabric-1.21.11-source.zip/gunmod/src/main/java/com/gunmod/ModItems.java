package com.gunmod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public final class ModItems {
    public static final Map<GunType, Item> GUNS = new EnumMap<>(GunType.class);
    public static final Map<GunType, Item> MAGAZINES = new EnumMap<>(GunType.class);

    private static Item register(String name, Item.Settings base, Function<Item.Settings, Item> factory) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(GunMod.MOD_ID, name));
        return Registry.register(Registries.ITEM, key, factory.apply(base.registryKey(key)));
    }

    public static void init() {
        for (GunType type : GunType.values()) {
            List<Text> lore = new ArrayList<>();
            for (String line : type.stats()) {
                lore.add(Text.literal(line).setStyle(Style.EMPTY.withColor(Formatting.GRAY).withItalic(false)));
            }
            lore.add(Text.literal("Sneak + right-click to inspect").setStyle(Style.EMPTY.withColor(Formatting.DARK_GRAY).withItalic(false)));
            Item.Settings gunSettings = new Item.Settings().maxCount(1).component(DataComponentTypes.LORE, new LoreComponent(lore));
            GUNS.put(type, register(type.id, gunSettings, s -> new GunItem(s, type)));
            MAGAZINES.put(type, register(type.id + "_magazine", new Item.Settings().maxCount(16), Item::new));
        }
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            for (Item item : GUNS.values()) entries.add(item);
            for (Item item : MAGAZINES.values()) entries.add(item);
        });
    }
}
