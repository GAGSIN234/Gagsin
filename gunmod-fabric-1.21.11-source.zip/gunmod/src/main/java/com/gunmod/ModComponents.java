package com.gunmod;

import com.mojang.serialization.Codec;
import net.minecraft.component.ComponentType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModComponents {
    /** Rounds currently loaded in the gun. */
    public static final ComponentType<Integer> AMMO = register("ammo",
            ComponentType.<Integer>builder().codec(Codec.INT).packetCodec(PacketCodecs.VAR_INT).build());
    /** World time the current reload started, or -1 when not reloading. */
    public static final ComponentType<Long> RELOAD_START = register("reload_start",
            ComponentType.<Long>builder().codec(Codec.LONG).packetCodec(PacketCodecs.VAR_LONG).build());
    /** World time at which the gun may fire again. */
    public static final ComponentType<Long> READY_AT = register("ready_at",
            ComponentType.<Long>builder().codec(Codec.LONG).packetCodec(PacketCodecs.VAR_LONG).build());

    private static <T> ComponentType<T> register(String name, ComponentType<T> type) {
        return Registry.register(Registries.DATA_COMPONENT_TYPE, Identifier.of(GunMod.MOD_ID, name), type);
    }

    public static void init() {}
}
