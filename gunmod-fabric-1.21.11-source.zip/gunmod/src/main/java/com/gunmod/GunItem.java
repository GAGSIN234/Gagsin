package com.gunmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class GunItem extends Item {
    public final GunType type;

    public GunItem(Settings settings, GunType type) {
        super(settings);
        this.type = type;
    }

    // ------------------------------------------------------------ state helpers
    public static int ammo(ItemStack s) { return s.getOrDefault(ModComponents.AMMO, 0); }
    public static boolean reloading(ItemStack s) { return s.getOrDefault(ModComponents.RELOAD_START, -1L) >= 0L; }

    /** Keeps the held gun from replaying the "re-equip" animation every time ammo changes. */
    public boolean allowComponentsUpdateAnimation(PlayerEntity player, Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    // ------------------------------------------------------------ right-click
    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!(world instanceof ServerWorld sw) || !(user instanceof ServerPlayerEntity p)) {
            return ActionResult.SUCCESS; // client side: just swing
        }
        ItemStack stack = p.getStackInHand(hand);

        if (p.isSneaking()) {            // INSPECT
            inspect(p, stack);
            return ActionResult.SUCCESS;
        }
        if (reloading(stack)) return ActionResult.FAIL;
        long now = sw.getTime();
        if (now < stack.getOrDefault(ModComponents.READY_AT, 0L)) return ActionResult.FAIL;
        if (ammo(stack) <= 0) {          // empty -> start this gun's reload
            startReload(sw, p, stack);
            return ActionResult.FAIL;
        }
        shoot(sw, p, stack, now);
        return ActionResult.SUCCESS;
    }

    private void inspect(ServerPlayerEntity p, ItemStack stack) {
        p.playSound(SoundEvents.ITEM_SPYGLASS_USE, 0.7f, 1.3f);
        p.sendMessage(Text.literal("== " + type.displayName + " ==").formatted(Formatting.GOLD, Formatting.BOLD), false);
        for (String line : type.stats()) {
            p.sendMessage(Text.literal(line).formatted(Formatting.GRAY), false);
        }
        String state = reloading(stack) ? "reloading..." : ammo(stack) + " / " + type.magSize;
        p.sendMessage(Text.literal("Loaded: " + state).formatted(Formatting.YELLOW), false);
        p.sendMessage(Text.literal("Magazine: " + type.magName).formatted(Formatting.AQUA), false);
    }

    // ------------------------------------------------------------ shooting
    private void shoot(ServerWorld w, ServerPlayerEntity p, ItemStack stack, long now) {
        int left = ammo(stack) - 1;
        stack.set(ModComponents.AMMO, left);
        stack.set(ModComponents.READY_AT, now + type.cooldown);
        p.playSound(type.shotSound, 1.8f, type.shotPitch);

        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVector();
        w.spawnParticles(ParticleTypes.SMOKE, eye.x + look.x, eye.y - 0.15 + look.y, eye.z + look.z, 3, 0.05, 0.05, 0.05, 0.01);

        RegistryEntry<DamageType> entry = w.getRegistryManager().getOrThrow(RegistryKeys.DAMAGE_TYPE).getOrThrow(GunMod.BULLET);
        DamageSource source = new DamageSource(entry, p);

        Map<LivingEntity, Float> hits = new LinkedHashMap<>();
        for (int i = 0; i < type.pellets; i++) fireRay(w, p, eye, look, hits);
        for (Map.Entry<LivingEntity, Float> hit : hits.entrySet()) {
            hit.getKey().damage(w, source, hit.getValue());
        }

        if (left == 0) {
            p.sendMessage(Text.literal(type.displayName + "  0 / " + type.magSize + "  - click to reload").formatted(Formatting.RED), true);
        } else {
            p.sendMessage(Text.literal(type.displayName + "  " + left + " / " + type.magSize), true);
        }
    }

    private void fireRay(ServerWorld w, ServerPlayerEntity p, Vec3d eye, Vec3d look, Map<LivingEntity, Float> hits) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Vec3d dir = look.add(r.nextGaussian() * type.spread, r.nextGaussian() * type.spread, r.nextGaussian() * type.spread).normalize();
        Vec3d end = eye.add(dir.multiply(type.range));

        BlockHitResult blockHit = w.raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        Vec3d stop = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getPos();

        Box box = p.getBoundingBox().stretch(dir.multiply(type.range)).expand(1.0);
        EntityHitResult entityHit = ProjectileUtil.raycast(p, eye, stop, box,
                (Entity e) -> !e.isSpectator() && e.canHit(), (double) type.range * type.range);
        if (entityHit != null) {
            stop = entityHit.getPos();
            if (entityHit.getEntity() instanceof LivingEntity living) {
                hits.merge(living, type.damage, Float::sum);
            }
        }

        double length = eye.distanceTo(stop);
        double step = length > 60 ? 3.0 : 1.5;
        for (double d = 2.0; d < length; d += step) {
            Vec3d pt = eye.add(dir.multiply(d));
            w.spawnParticles(ParticleTypes.CRIT, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
        }
        w.spawnParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 4, 0.1, 0.1, 0.1, 0.05);
    }

    // ------------------------------------------------------------ reloading
    private void startReload(ServerWorld w, ServerPlayerEntity p, ItemStack gun) {
        if (!p.isCreative()) {
            Item mag = ModItems.MAGAZINES.get(type);
            PlayerInventory inv = p.getInventory();
            boolean found = false;
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.isOf(mag)) { s.decrement(1); found = true; break; }
            }
            if (!found) {
                p.sendMessage(Text.literal("No " + type.magName + " in your inventory!").formatted(Formatting.RED), true);
                p.playSound(SoundEvents.BLOCK_DISPENSER_FAIL, 0.8f, 1.5f);
                return;
            }
        }
        gun.set(ModComponents.RELOAD_START, w.getTime());
        p.playSound(SoundEvents.BLOCK_LEVER_CLICK, 0.8f, 1.0f);
    }

    private void cancelReload(ServerPlayerEntity p, ItemStack gun) {
        gun.set(ModComponents.RELOAD_START, -1L);
        if (ammo(gun) == 0 && !p.isCreative()) {            // give the unused magazine back
            p.getInventory().offerOrDrop(new ItemStack(ModItems.MAGAZINES.get(type)));
        }
        p.sendMessage(Text.literal("Reload cancelled").formatted(Formatting.GRAY), true);
    }

    private void finish(ServerPlayerEntity p, ItemStack gun, SoundEvent sound, float pitch) {
        gun.set(ModComponents.AMMO, type.magSize);
        gun.set(ModComponents.RELOAD_START, -1L);
        p.playSound(sound, 0.9f, pitch);
        p.sendMessage(Text.literal(type.displayName + "  " + type.magSize + " / " + type.magSize).formatted(Formatting.GREEN), true);
    }

    private static void snd(ServerPlayerEntity p, SoundEvent s, float pitch) { p.playSound(s, 0.9f, pitch); }

    private static String bar(float f) {
        int n = Math.round(Math.max(0f, Math.min(1f, f)) * 12);
        return "[" + "#".repeat(n) + "-".repeat(12 - n) + "]";
    }

    /** Called every tick for each player: cancels reloads when the gun leaves the hands, advances the held gun. */
    public static void tickPlayer(ServerWorld w, ServerPlayerEntity p) {
        ItemStack main = p.getMainHandStack();
        ItemStack off = p.getOffHandStack();
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s != main && s != off && s.getItem() instanceof GunItem g && reloading(s)) g.cancelReload(p, s);
        }
        if (main.getItem() instanceof GunItem g) g.tickHeld(w, p, main);
        if (off.getItem() instanceof GunItem g) g.tickHeld(w, p, off);
    }

    private void tickHeld(ServerWorld w, ServerPlayerEntity p, ItemStack s) {
        long now = w.getTime();

        // Pump / bolt cycle sounds while waiting between shots
        if (type.cycles) {
            long ready = s.getOrDefault(ModComponents.READY_AT, 0L);
            boolean sniper = type == GunType.SNIPER_RIFLE;
            if (now == ready - type.cooldown / 2) snd(p, sniper ? SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN : SoundEvents.BLOCK_PISTON_EXTEND, sniper ? 1.4f : 1.3f);
            if (now == ready - 4) snd(p, sniper ? SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE : SoundEvents.BLOCK_PISTON_CONTRACT, sniper ? 1.4f : 1.3f);
        }

        long start = s.getOrDefault(ModComponents.RELOAD_START, -1L);
        if (start < 0) return;
        long e = now - start;
        if (e % 2 == 0) {
            p.sendMessage(Text.literal("Reloading " + bar(e / (float) type.reloadTicks)).formatted(Formatting.YELLOW), true);
        }

        switch (type) {
            case PISTOL -> {            // quick mag swap
                if (e == 6) snd(p, SoundEvents.ITEM_CROSSBOW_LOADING_START, 1.8f);
                if (e == 20) snd(p, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, 1.9f);
                if (e >= 30) finish(p, s, SoundEvents.BLOCK_LEVER_CLICK, 1.6f);
            }
            case REVOLVER -> {          // speedloader
                if (e == 8) snd(p, SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN, 2.0f);
                if (e == 20) snd(p, SoundEvents.BLOCK_CHAIN_BREAK, 1.6f);
                if (e == 34) snd(p, SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE, 1.2f);
                if (e == 46) snd(p, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, 2.0f);
                if (e >= 52) finish(p, s, SoundEvents.BLOCK_LEVER_CLICK, 1.3f);
            }
            case SMG -> {               // drop-mag
                if (e == 3) snd(p, SoundEvents.BLOCK_LEVER_CLICK, 1.7f);
                if (e == 9) snd(p, SoundEvents.ITEM_CROSSBOW_LOADING_END, 1.9f);
                if (e >= 14) finish(p, s, SoundEvents.BLOCK_LEVER_CLICK, 1.9f);
            }
            case ASSAULT_RIFLE -> {     // mag out/in, then charging handle
                if (e == 8) snd(p, SoundEvents.BLOCK_LEVER_CLICK, 1.2f);
                if (e == 22) snd(p, SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE, 0.8f);
                if (e == 38) snd(p, SoundEvents.BLOCK_PISTON_EXTEND, 2.0f);
                if (e == 44) snd(p, SoundEvents.BLOCK_PISTON_CONTRACT, 2.0f);
                if (e >= 50) finish(p, s, SoundEvents.BLOCK_LEVER_CLICK, 1.0f);
            }
            case SHOTGUN -> {           // one shell at a time, then pump
                long step = 9;
                if (e > 0 && e % step == 0 && e / step <= type.magSize) {
                    s.set(ModComponents.AMMO, (int) (e / step));
                    snd(p, SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE, 1.5f);
                }
                long loaded = step * type.magSize;
                if (e == loaded + 6) snd(p, SoundEvents.BLOCK_PISTON_EXTEND, 1.3f);
                if (e >= loaded + 12) finish(p, s, SoundEvents.BLOCK_PISTON_CONTRACT, 1.3f);
            }
            case SNIPER_RIFLE -> {      // bolt up/back, clip in, bolt forward/down
                if (e == 8) snd(p, SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN, 1.4f);
                if (e == 18) snd(p, SoundEvents.BLOCK_PISTON_EXTEND, 1.6f);
                if (e == 32) snd(p, SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE, 0.9f);
                if (e == 44) snd(p, SoundEvents.BLOCK_PISTON_CONTRACT, 1.6f);
                if (e >= 56) finish(p, s, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, 1.4f);
            }
        }
    }
}
